import os
from flask import Flask, render_template, request, redirect, url_for, jsonify
from load_pages import *
import subprocess as sp

app = Flask(__name__)

ranks = hashmap_pagerank()

@app.route("/")
def home(): 
    return render_template('index.html')

@app.route("/verDocumento",methods=['GET'])
def verDocumento():
    nameDocument=request.args.get('documento')
    consulta=f"hadoop dfs -cat /input/{nameDocument}"
    output = sp.getoutput(consulta)
    return output

@app.route("/new", methods=["POST"])  # Actualizado a /new        
def search():
    page_rank = {}

    words = request.form['busqueda']
    words = words.lower().split()
    
    response  = search_query(words)
    pagelist = []

    if not len(response):
        return redirect(url_for('home'))
    else:
        for lista in response:
            for page in lista[0]:
                if page in page_rank: 
                    page_rank[page][1] += ' '+lista[1]
                else:   
                    page_rank[page] = [ranks[page], lista[1]]

        page_rank = {k: v for k, v in sorted(page_rank.items(), reverse=True, key=lambda item: item[1][0])} 

        output = {}
        contador = 10
        for k, v in page_rank.items():
            if contador == 0:
                break
            output[k] = v
            contador -= 1

        return render_template("resultados.html",
            busqueda=words,
            resultados=output
        )

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
